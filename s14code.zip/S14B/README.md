uv run utils/fdom/element_interactor.py --app-name "C:\Program Files\WindowsApps\Microsoft.WindowsNotepad_11.2504.52.0_x64__8wekyb3d8bbwe\Notepad\Notepad.exe" --interactive

uv run utils/fdom/element_interactor.py --app-name "C:\Program Files\WindowsApps\Microsoft.WindowsNotepad_11.2504.58.0_x64__8wekyb3d8bbwe\Notepad\Notepad.exe" --interactive


uv run utils/fdom/element_interactor.py --app-name "C:\Program Files\Blender Foundation\Blender 4.2\blender.exe" --interactive

uv run utils/fdom/element_interactor.py --app-name "C:\Program Files (x86)\Microsoft Office\root\Office16\POWERPNT.EXE" --interactive